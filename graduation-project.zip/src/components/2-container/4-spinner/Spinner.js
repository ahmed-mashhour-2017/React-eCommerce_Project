import React from 'react'
import './spinner.css';
export default function MySpinner() {
  return (
    <>
    <div>
    <div className="lds-grid"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
    </div>
    </>
  )
}
