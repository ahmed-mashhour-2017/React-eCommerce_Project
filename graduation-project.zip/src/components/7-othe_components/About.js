import React from 'react'

export default function About() {
  return (
    <>
    	<div id="About-us"className="container border2 p-20"  >
											<div className="col-10 border border-1 border-dark p-5">
												<div className=" ">
														<div className=" ">
															<h3>Who We Are</h3>
															<img src="images/about_img.jpg" alt="" / >
															<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
															<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
														</div>
														<div className=" ">
															<h3>Our History</h3>
														 <div className=" ">
															<div className="year"><p>1998 -</p></div>
															<p className="history">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
														 <div className="clear"></div>
														</div>
														 <div className=" ">
															<div className="year"><p>2001 -</p></div>
															<p className="history">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
														 <div className="clear"></div>
														</div>
														 <div className=" ">
															<div className="year"><p>2006 -</p></div>
															<p className="history">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
														 <div className="clear"></div>
														</div>
														 <div className=" ">
															<div className="year"><p>2010 -</p></div>
															<p className="history">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
														 <div className="clear"></div>
														</div>
														<div className=" ">
															<div className="year"><p>2013 -</p></div>
															<p className="history">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
														 <div className="clear"></div>
														</div>
													</div>
													 
													</div>			
											</div>
										 </div>
    </>
  )
}
