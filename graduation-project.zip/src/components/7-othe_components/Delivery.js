import React from 'react'

export default function Delivery() {
  return (
    <>
    	<div id="Delivery"className=" align-self-center col-8 border border-1 border-dark  p-4 mx-auto">
											<div className=" ">
												<div className=" ">
														<div className="col-5">
															<img src="images/delivery.jpg" alt="..."className="rounded-5" />
															 </div>
														<div   className="col-8 offset-2 ">
															 
															<h3>Lorem Ipsum is simply dummy text </h3>
															<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
														</div>
														 
													</div>	
													
												</div> 
											</div>
    </>
  )
}
