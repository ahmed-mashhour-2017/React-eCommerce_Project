import React from 'react'

export default function Error() {
  return (
    <div>Page Not Found</div>
  )
}
