import React from 'react'
import './product.css'
export default function Product({  data}) {
 
    let TheItemsProducts=data.map((item,i)=>{
        return (         
         <div  key={i} className="col-md-3 col-sm-12">
        <div className="item">
            <div >
                <img src={item.image} alt=""/>
                <div className="body">
                    <h4>{ item.title }</h4>
                    <p>{ item.description }</p>
                </div>
            </div>

            <div className="px-3 mb-2 d-flex justify-content-between align-datas-center ">
                <button className="btn btn-success"  >Add To Cart</button>
                <div className="d-flex w-50"  >
                    <input type="number" className="form-control" />
                    <button className="btn btn-danger"  >Add</button>
                </div>
                <span>{item.price} L.E</span>
                <br/>
            </div>
        </div>
        </div>
        );
    });
  return (
    <>
  
       {TheItemsProducts}
    </>
  )
}
